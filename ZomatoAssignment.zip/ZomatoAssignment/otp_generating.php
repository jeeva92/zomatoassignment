<?php 
//include_once('Main.php');
$mobile_number = $_POST['mobile'];
$otp = rand(1000, 9999);
//$ot->update_otp($mobile_number,$otp);
echo $otp;
?>