<?php
if (session_status() == PHP_SESSION_NONE) { session_start();
}
include_once('header.php');
include_once('Main.php');

 ?>

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />


<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css" rel="stylesheet" /> -->

<section class="hero-wrap d-flex align-items-center background-image-bike">
<div class="container marginFixing">
<div class="row d-flex justify-content-center">
<div class="hero-title">
<h1>Surf Dining</h1>
<h3>Find out perfect place to hangout in your city from over 1 Million Restaurants </h3>
</div>
</div>
<div class="row">
<div class="col-md-12">
<form action="restaurant-detail.php" method="post">
<div class="search-box">
<div class="row">
<div class="col-md-6 search-box_line">
<div class="search-box1">
<div class="search-box-title">
<label>Where?</label><br>
<!-- <input type="text" name="#" class="search-form" placeholder="Eg: restaurant, spa, shopping"> -->
<input list="cities" type="text" name="city" id="city" class="search-form" placeholder="Eg:  Chennai, Delhi" required>
<datalist id="cities">
  <option value="Popular Locations" disabled >
  <option value="Chennai"  >
  <option value="Bangalore"  >
  <option value="Hyderbad"  >
</datalist>  
</div>
</div>
</div>
<div class="col-md-6">
<div class="search-box2">
<div class="search-box-title">
<label>Restaurant?</label><br>
<div id="restaurants">
<!--<select class="selectpicker search-form resta" data-show-subtext="true" data-live-search="true" name="restaurant" id="restaurant" >
<option data-tokens="name">name</option>
<option data-tokens="family">family</option>
</select> -->
</div>
<!-- <input list="restaurants" type="text" name="restaurant" id="restaurant" class="search-form" placeholder="Eg: KFC, Mc Donalds, Burger King" required>
<datalist id="restaurants">
  <option value="KFC">
  <option value="Burger King">
  <option value="Mc Donalds">
  <option value="Zaitoon Multi Cuisine Restaurant">
  <option value="A2B Restaurant">
</datalist> -->
</div>
</div>
</div>
</div>
</div>
<div class="btn-search">
<button name="submit" class="btn btn-simple">Search </button>
</div>
</form>
<div class="clearfix"></div>
<!-- <img src="images/bike-art.png" alt="restaurant-detials-near-me" /> -->
</div>
</div>
</div>
</section>

<?php include_once('footer.php'); ?>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>
<script>
$('document').ready( function () {	
$(function() {
  $('.selectpicker').selectpicker();
});

 $('body').on('keyup', 'input#city', function (event) {	
         if(event.keyCode === 13){          
		 }else{			 		 
		 var city=$('#city').val();		  
		 $.ajax({
          url:"ajax_supporting.php",
          data:{city:city},
          type : 'POST' ,	
          cache:false,
          success:function(data){              		  
                  $("#cities").html(data); 
          }
        });	
		}
	 });

 $('body').on('change', 'input#city', function () {	
           var city=$('#city').val();	
		  //alert(city);
	      $.ajax({
           url:"ajax_restaurantlist.php",
           data:{city:city},
          type : 'POST' ,	
           cache:false,
           success:function(data){	                  
                  $("#restaurants").html(data); 
				 // sessionStorage.sess_city_id = 				
				 alert(data);
				//  document.getElementByClass("resta").style.display = "none";
				 document.getElementByClass("restax").style.display = "block";
           }
         });	
  }); 
 /* $('body').on('change', 'select#restaurant', function () {	
           var rest_id =$('#restaurant').val();		  
		   alert(rest_id);
		   sessionStorage.setItem('sess_res_id', rest_id);
		   alert(sessionStorage.getItem('sess_city_id'));
		   $.ajax({
           url:"ajax_restaurantsessionid.php",
           data:{rest:rest,city_id:city_id,rest_locality : rest_locality},
          type : 'POST' ,	
           cache:false,
           success:function(data){	
		     alert(data);
           }
         });	
	       
  });  */ 
});
</script>
 <!---->