<?php 
include_once('Main.php');
$ot->logout();
//session_destroy();
// echo "
// <script type=\"text/javascript\">
// window.location='restaurant-detail.php';
// </script>
// ";
?>