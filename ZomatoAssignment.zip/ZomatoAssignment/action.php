<?php if( isset($_POST['restaurant']) ){  
echo "
<script type=\"text/javascript\">
window.location='restaurant-detail.php';
</script>
";
 } else { echo "something wrong"; echo $_SESSION['sess_city_id']; echo $_SESSION['sess_res_id']; }?>