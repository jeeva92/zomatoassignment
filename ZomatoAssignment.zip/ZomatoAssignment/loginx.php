<?php
if (session_status() == PHP_SESSION_NONE) { session_start();
}
if(isset($_SESSION['mobile_no'])){
	echo "
<script type=\"text/javascript\">
window.location='restaurant-detail.php';
</script>
";
}
include_once('header1.php');
include_once('Main.php');

 ?>


<section class="hero-wrap d-flex align-items-center background-image-bike">
<div class="container marginFixing">
<div class="row d-flex justify-content-center">
<div class="container " id="otpsend">
		<div class="error"></div>
		<form id="frm-mobile-verification">
			<div class="form-heading"><label>Mobile Number Verification</label></div>		
				<input type="number" name="mobile_no" id="mobile" class="form-input"
					placeholder="Enter the 10 digit mobile">
			<input type="button" id="sendotp" class="btnSubmit" value="Send OTP"
				onClick="sendOTP();">
		</form>
	</div>
	<div id="enterotp1" > This is your OTP Code, Kindly enter this number to Login : <span class="otpcode"></span></div>
	<div class="container " id="enterotp">
		<div class="error"></div>
		<form id="frm-mobile-verification">
			<div class="form-heading"><label>Enter Your OTP</label></div>		
				<input type="number" name="otp" id="otp" class="form-input"
					placeholder="4321">
			<input type="button" id="verifyotp" class="btnSubmit" value=" Submit " onClick="verifyOTP();">
		</form>
	</div>
	</div>
	</div>
	</section>
	<?php include_once('footer.php'); ?>
	<script>
	$('document').ready( function () {	
	document.getElementById("otpsend").style.display = "block";
	document.getElementById("enterotp").style.display = "none";
	document.getElementById("enterotp1").style.display = "none";
	$('body').on('click', 'input#sendotp',function sendOTP() {		
	$(".error").html("").hide();
	var number = $("#mobile").val();
	if (number.length == 10 && number != null) {
		
		$.ajax({
			url : 'otp_generating.php',
			type : 'POST',
			data : {mobile : number},
			success : function(response) {
				$(".otpcode").html(response);
			}
		});
		document.getElementById("otpsend").style.display = "none";
	    document.getElementById("enterotp").style.display = "block";
		document.getElementById("enterotp1").style.display = "block";
	} else {
		$(".error").html('Please enter a valid number!')
		$(".error").show();
	}
});
    $('body').on('click', 'input#verifyotp',function verifyOTP() {		
	var generated_otp = $(".otpcode").html();	
	var otp = $("#otp").val();	
	if (otp.length == 4 && otp == generated_otp ) {
		var number = $("#mobile").val();		
		//sessionStorage.setItem('mobile_no', number); 
         $.ajax({
			url : 'mobilenumber_session.php',
			type : 'POST',
			data : {mobile : number},
			success : function(response) {
				window.location='restaurant-detail.php';
			}
		});       	
				
	} else {
		$(".error").html('Please enter a valid OTP!')
		$(".error").show();
	}
});
	});
	</script>