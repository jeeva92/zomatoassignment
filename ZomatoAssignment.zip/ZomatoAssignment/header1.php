<!DOCTYPE html>
<html lang="en">
<?php if (session_status() == PHP_SESSION_NONE) { session_start();
} ?>
<head>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<script src="/cdn-cgi/apps/head/-mEFVS8y7qx5pVzWHQTCQu5gnVM.js"></script><link rel="shortcut icon" href="#">

<title>Zomato - Social Beat Assignment</title>

<link rel="stylesheet" href="css/bootstrap.min.css">

<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">

<link rel="stylesheet" href="css/themify-icons.css">

<link rel="stylesheet" href="css/fontawesome.min.css">

<link href="css/style2.css" rel="stylesheet">

<link rel="stylesheet" href="css/style.css">
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
</head>
<body>

<div class="nav-menu sticky-top" >
<div class="bg transition">
<div class="container-fluid fixed">
<div class="row">
<div class="col-md-12">
<nav class="navbar navbar-expand-lg">
<a class="navbar-brand" href="index.php"> Zomato Restaurant</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
<span class="ti-menu"></span>
</button>
<div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown"> 
<ul  hidden class="navbar-nav">
<?php if(!isset($_SESSION['mobile_no'])){ ?>
<li class="nav-item">
<a class="nav-link" href="login.php" >Login</a>
</li>
<?php } ?>
<?php if(isset($_SESSION['mobile_no'])){ ?>
<li class="nav-item dropdown">
<a class="nav-link" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<?=$_SESSION['mobile_no']?>
<span class="ti-angle-down"></span>
</a>
<div class="dropdown-menu">
<a class="dropdown-item" href="logout.php" id="logout" > Logout </a>
</div>
</li>
<?php } ?>
</ul>
</div>
</nav>
</div>
</div>
</div>
</div>
</div>