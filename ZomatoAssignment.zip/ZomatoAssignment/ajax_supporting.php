<?php
$ch = curl_init();
//$url = "https://developers.zomato.com/api/v2.1/search?entity_id=7&entity_type=city&q=".$_POST['city'];
//echo $url; exit;
$url = "https://developers.zomato.com/api/v2.1/cities?q=".$_POST['city'];
curl_setopt($ch, CURLOPT_URL, $url );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
$headers = array(
  "Accept: application/json",
  "User-Key: d1e5aa34ddcd97cd143e2a0ed7193a0d"
  );
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close ($ch);
 $json_data = json_decode($result);  
session_start();

?>

<datalist id="cities">
  <option value="" disabled selected>Select the option</option>
  <?php $i= 0; 
  foreach($json_data->location_suggestions as $res){ 
  ++$i;
  if($i == 1){
	  $_SESSION['sess_city_id'] = $res->id;
  } ?>
<option value="<?=$res->name?>"></option>
<?php } ?>                                 
</datalist> 