<footer class="main-block black">
<div class="container-fluid">
<div class="row">
<div class="col-md-4 responsive-wrap">
<div class="location">
<!--<i class="fa fa-map-marker" aria-hidden="true"></i>
<p>503 Sylvan Ave, Mountain View<br> CA 94041, United States</p> -->
</div>
</div>
<div class="col-md-4 responsive-wrap">
<div class="footer-logo_wrap">
<div class="copyright">
<p>Copyright © 2019 XXXX Pvt LTD. All rights reserved</p>
<!--<a href="#">Privacy</a>
<a href="#">Terms</a> -->
</div>
</div>
</div>
<div class="col-md-4 responsive-wrap">
<ul class="social-icons">
<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a></li>
</ul>
</div>
</div>

</div>
</footer>



<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>