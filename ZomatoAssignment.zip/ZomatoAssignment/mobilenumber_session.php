<?php 
if(session_status() == PHP_SESSION_NONE){
	session_start();
}
$_SESSION['mobile_no'] = $_POST['mobile'];

?>