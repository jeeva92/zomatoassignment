<?php include_once('header.php');
if (session_status() == PHP_SESSION_NONE) { session_start();
} 
if(isset($_POST['publish_review'])){
	include_once('Main.php');
	$resultx = $ot->add_review();
	if($resultx){
		// echo "
// <script type=\"text/javascript\">
// window.location='restaurant-detail.php';
// </script>
// ";
	}
}
if(isset($_POST['restaurant']) || isset($_SESSION['sess_res_id'])){
	if(isset($_POST['restaurant'])){
		$_SESSION['sess_res_id'] = $_POST['restaurant'];
	include_once('Main.php');
	$restaurant = $ot->getRestaurantDetails($_POST['restaurant']);
	$reviews = $ot->getRestaurantReviews($_POST['restaurant']);
	}elseif(isset($_SESSION['mobile_no'])){
		include_once('Main.php');
	$restaurant = $ot->getRestaurantDetails($_SESSION['sess_res_id']);
	$reviews = $ot->getRestaurantReviews($_SESSION['sess_res_id']);
	}
}else{
	echo "
<script type=\"text/javascript\">
window.location='index.php';
</script>
";
}
 ?>

<section class="reserve-block">
<div class="container">
<div class="row">
</div>
</div>
</section>


<section class="gray-dark booking-details_wrap">
<div class="container">
<div class="row">
<div class="col-md-10 responsive-wrap">
<div class="booking-checkbox_wrap">
<div class="booking-checkbox">
<h2><?=$restaurant->name ?> </h2>
<p> <?= $restaurant->location->locality ?><span> - <?php $i = count($restaurant->establishment);$j=1; foreach($restaurant->establishment as $est){ if( $i == $j ){ echo $est; }else {echo $est.','; } $j++; }?></span></p>
<p> Phone Number : <?= $restaurant->phone_numbers ?></p>
<?php  $userrating = $restaurant->user_rating->rating_text."( ".$restaurant->user_rating->aggregate_rating."/5 )<br />".$restaurant->user_rating->votes." votes<br/>"; ?>
<p class="customer-rating" style="margin-top:-5%"> <?= $userrating ?> </p>
<p><label> Address : </label> <?=$restaurant->location->address?>,<?=$restaurant->location->locality?>,<?=$restaurant->location->city?> </p>
<hr>
</div>
<div class="row">
<div class="col-md-6 col-lg-6">
<label class="custom-checkbox">
<span class="ti-check-box"></span>
<span class="custom-control-description">Avg Cost for 2 : <?=$restaurant->average_cost_for_two?> </span>
</label>
</div>
<div class="col-md-6 col-lg-6">
<label class="custom-checkbox">
<span class="ti-check-box"></span>
<span class="custom-control-description">Timing : <?=$restaurant->timings?> </span>
</label>
</div>
<div class="col-md-6 col-lg-6">
<label class="custom-checkbox">
<span class="ti-check-box"></span>
<span class="custom-control-description">Cuisines : <?=$restaurant->cuisines?></span>
</label>
</div>
<div class="col-md-6 col-lg-6">
<label class="custom-checkbox">
<span class="ti-check-box"></span>
<span class="custom-control-description"> Highlights : <?php for($j=0;$j<4;$j++){ if( 4 == $j ){ echo $restaurant->highlights[$j]; }else {echo $restaurant->highlights[$j].','; } } ?></span>
</label>
</div>

</div>
</div>
<div class="booking-checkbox_wrap booking-your-review">
<h5>Write a Review</h5>
<hr>
<?php // if(isset($_SESSION['mobile_no'])){ ?>
<form  method="post" >
<div class="customer-review_wrap">
<p><?=$_SESSION['mobile_no']?></p>
<div class="customer-content-wrap">
<div hidden class="your-rating-wrap">
<span>Your rating</span>
<div class="customer-review">
<span></span>
<span></span>
<span></span>
<span></span>
<span class="round-icon-blank"></span>
</div>
</div>
<div class="your-comment-wrap">
<textarea name="review_text" class="your-rating-content" placeholder="Enter Your Comments"></textarea>
<h6 class="your-rating-notify">at least 140 characters</h6>
</div>
<div class="row">
<div class="col-md-4 mr-auto">
<div class="add-photos-link mb-3 mb-md-0">
</div>
</div>
<div class="col-md-4">
<div class="your-rating-btn">
<button name="publish_review" class="btn btn-danger btn-block" >Publish Review</button>
</div>
</div>
</div>
</div>
</div>
</form>
<?php //} else { ?>
<!-- <div class="customer-review_wrap"> <a href="loginx.php" class="btn btn-md btn-danger "> Login to make a review </a></div> -->
<?php // } ?>
</div>
<div class="booking-checkbox_wrap my-4">
<h4>Your Reviews About this Restaurant</h4>
<hr>
<?php $myreviews = $ot->get_review($_SESSION['mobile_no'],$_SESSION['sess_res_id']);
if(count($myreviews) >0){
foreach($myreviews as $reviewx){ ?>
<div class="customer-review_wrap">
<div class="customer-img">

<p><?=$reviewx['cus_id']?></p>

</div>
<div class="customer-content-wrap">
<div class="customer-content">
<div class="customer-review">
<h5></h5>
<span></span>
<span></span>
 <span></span>
<span></span>
<span class="round-icon-blank"></span>
<p>Reviewed 2 days ago</p>
</div>
<div class="customer-rating"><?=$reviewx['rating']?> / 5 </div>
</div>
<p class="customer-text"><?=$reviewx['review_description']?> </p>

</div>
</div>
<hr>
<?php }  } else{
echo " You didn`t made any reviews yet about this restaurant" ; }?>

</div>


<div class="booking-checkbox_wrap my-4">
<h4>showing 5 / <?=$reviews->reviews_count?> Reviews</h4>
<hr>
<?php foreach($reviews->user_reviews as $review){ ?>
<div class="customer-review_wrap">
<div class="customer-img">
<img src="<?=$review->review->user->profile_image?>" class="img-fluid" alt="#">
<p><?=$review->review->user->name?></p>

</div>
<div class="customer-content-wrap">
<div class="customer-content">
<div class="customer-review">
<h5></h5>
<span></span>
<span></span>
 <span></span>
<span></span>
<span class="round-icon-blank"></span>
<p>Reviewed 2 days ago</p>
</div>
<div class="customer-rating"><?=$review->review->rating?> / 5 </div>
</div>
<p class="customer-text"><?=$review->review->review_text?> </p>

</div>
</div>
<hr>
<?php } ?>

</div>
</div>
</div>
</div>
</section>


<?php include_once('footer.php'); ?>


<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.magnific-popup.js"></script>

<script>
        var swiper = new Swiper('.swiper-container', {
            slidesPerView: 3,
            slidesPerGroup: 3,
            loop: true,
            loopFillGroupWithBlank: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
    </script>
<script>
        if ($('.image-link').length) {
            $('.image-link').magnificPopup({
                type: 'image',
                gallery: {
                    enabled: true
                }
            });
        }
        if ($('.image-link2').length) {
            $('.image-link2').magnificPopup({
                type: 'image',
                gallery: {
                    enabled: true
                }
            });
        }
    </script>
</body>
</html>