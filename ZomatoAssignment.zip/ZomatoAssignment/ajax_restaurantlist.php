<?php
$ch = curl_init();
//$url = "https://developers.zomato.com/api/v2.1/search?entity_id=7&entity_type=city&q=".$_POST['city'];
//echo $url; exit;
$url = "https://developers.zomato.com/api/v2.1/cities?q=".$_POST['city'];
curl_setopt($ch, CURLOPT_URL, $url );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
$headers = array(
  "Accept: application/json",
  "User-Key: d1e5aa34ddcd97cd143e2a0ed7193a0d"
  );
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close ($ch);
 $json_data = json_decode($result);  
 //print_r($json_data->location_suggestions); exit;
   $i= 0; 
   foreach($json_data->location_suggestions as $res){ 
   ++$i;
   if($i == 1){
	   $_SESSION['sess_city_id'] = $res->id;
	  
   } }

$ch = curl_init();
$url = "https://developers.zomato.com/api/v2.1/search?entity_id=".$_SESSION['sess_city_id']."&entity_type=city"; 
curl_setopt($ch, CURLOPT_URL, $url );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
$headers = array(
  "Accept: application/json",
  "User-Key: d1e5aa34ddcd97cd143e2a0ed7193a0d"
  );
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close ($ch);
 $json_data = json_decode($result); 
 
?>
<select class="search-form selectpicker restax" data-show-subtext="true" data-live-search="true" name="restaurant" id="restaurant" style="display:block" >
<?php   foreach($json_data->restaurants as $res){ ?>
<option data-tokens="<?=$res->restaurant->name?>" value="<?=$res->restaurant->id?>" ><?=$res->restaurant->name?></option>
<?php } ?>  
</select>

<!-- <datalist id="restaurants">
  <option value="" disabled selected>Select the option</option>
  <?php   foreach($json_data->restaurants as $res){ ?>
<option value="<?=$res->restaurant->name?> , <?=$res->restaurant->location->locality?> " ></option>
<?php } ?>                                 
</datalist> -->